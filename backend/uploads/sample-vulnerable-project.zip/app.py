# Demo project for security scanning
API_KEY = "DEMO_FAKE_API_KEY_12345"

def get_user(user_id):
    query = "SELECT * FROM users WHERE id = " + user_id
    return query
