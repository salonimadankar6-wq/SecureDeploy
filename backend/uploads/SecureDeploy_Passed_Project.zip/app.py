import os
# Demo project for security scanning
API_KEY = os.getenv("API_KEY")

def get_user(user_id):
    query = "SELECT * FROM users WHERE id =  ?"
    params = (user_id,)
    return query
