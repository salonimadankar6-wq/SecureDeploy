# Sample Vulnerable Project

This is a deliberately insecure demo project for testing the DevSecOps scanner.
All credentials are fake and must not be used anywhere.
